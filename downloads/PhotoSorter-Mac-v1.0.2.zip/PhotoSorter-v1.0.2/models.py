"""
Модели данных для PhotoSorter.
"""

from dataclasses import dataclass, field
from pathlib import Path
from datetime import datetime
from enum import Enum
from typing import Optional


class FileType(Enum):
    """Тип медиа-файла."""
    PHOTO = "photo"
    VIDEO = "video"
    UNKNOWN = "unknown"


@dataclass
class FileInfo:
    """Информация о найденном медиа-файле."""
    path: Path
    file_type: FileType
    extension: str

    @property
    def name(self) -> str:
        return self.path.name


@dataclass
class FileResult:
    """Результат обработки одного файла."""
    source: Path
    destination: Optional[Path]
    date_found: Optional[datetime]
    exif_dates_found: list[str]
    status: str  # moved, copied, skipped, error, dry_run
    error: Optional[str] = None


@dataclass
class SortReport:
    """Отчёт о результатах сортировки."""
    total: int = 0
    moved: int = 0
    skipped: int = 0
    errors: int = 0
    results: list[FileResult] = field(default_factory=list)