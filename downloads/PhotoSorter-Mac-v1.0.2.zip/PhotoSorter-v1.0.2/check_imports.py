"""Проверка импортов всех модулей PhotoSorter."""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

print("🔍 Проверка импортов PhotoSorter...")
print(f"   PYTHONPATH: {sys.path[0]}")
print()

try:
    from photo_sorter.config import APP_NAME, APP_VERSION
    print(f"   ✅ config.py — {APP_NAME} v{APP_VERSION}")
except Exception as e:
    print(f"   ❌ config.py — {e}")

try:
    from photo_sorter.models import FileInfo, FileType, SortReport
    print(f"   ✅ models.py — FileInfo, FileType, SortReport")
except Exception as e:
    print(f"   ❌ models.py — {e}")

try:
    from photo_sorter.scanner import scan_folder
    print(f"   ✅ scanner.py — scan_folder")
except Exception as e:
    print(f"   ❌ scanner.py — {e}")

try:
    from photo_sorter.metadata import get_file_date, get_date_from_exif
    print(f"   ✅ metadata.py — get_file_date")
except Exception as e:
    print(f"   ❌ metadata.py — {e}")

try:
    from photo_sorter.logger import setup_logger, log_action
    print(f"   ✅ logger.py — setup_logger")
except Exception as e:
    print(f"   ❌ logger.py — {e}")

try:
    from photo_sorter.sorter import run_sort
    print(f"   ✅ sorter.py — run_sort")
except Exception as e:
    print(f"   ❌ sorter.py — {e}")

try:
    from photo_sorter.app import PhotoSorterApp
    print(f"   ✅ app.py — PhotoSorterApp")
except Exception as e:
    print(f"   ❌ app.py — {e}")

print()
print("🏁 Проверка завершена")