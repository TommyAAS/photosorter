#!/bin/bash
# =============================================
#  📸 PhotoSorter — Сборка .app для macOS
# =============================================
# Использование:
#   chmod +x build_mac_app.sh
#   ./build_mac_app.sh
# =============================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "============================================="
echo "  📸 PhotoSorter — Сборка .app для macOS"
echo "============================================="
echo ""

# Проверка Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 не найден. Установите Python 3.8+"
    echo "   brew install python"
    exit 1
fi
echo "✅ Python3 найден: $(python3 --version)"

# Генерируем иконку .icns
echo ""
echo "🎨 Генерация иконки .icns..."
python3 generate_icon.py --icns
if [ $? -eq 0 ]; then
    echo "✅ Иконка .icns создана"
else
    echo "⚠️  Не удалось создать .icns, пробуем .png"
    python3 generate_icon.py
fi

# Установка зависимостей
echo ""
echo "📦 Установка зависимостей..."
pip3 install -r requirements_mac.txt
echo "✅ Зависимости установлены"

# Установка py2app
echo ""
echo "📦 Установка py2app..."
pip3 install py2app
echo "✅ py2app установлен"

# Создание setup.py для py2app
echo ""
echo "📝 Создание setup.py..."
cat > setup.py << 'PYEOF'
"""
Setup-скрипт для сборки .app через py2app.
"""
from setuptools import setup

APP = ['main.py']
APP_NAME = "PhotoSorter"
DATA_FILES = []

# Опции для py2app
OPTIONS = {
    'argv_emulation': False,
    'packages': ['photo_sorter'],
    'iconfile': 'icon.icns',
    'plist': {
        'CFBundleName': APP_NAME,
        'CFBundleDisplayName': APP_NAME,
        'CFBundleIdentifier': 'com.photosorter.app',
        'CFBundleVersion': '1.0.1',
        'CFBundleShortVersionString': '1.0.1',
        'NSHighResolutionCapable': True,
        'NSRequiresAquaSystemAppearance': False,  # Поддержка тёмной темы
        'LSUIElement': False,  # Показывать в Dock
    },
    'resources': ['photo_sorter'],
    'includes': [
        'PIL', 'PIL._imaging', 'customtkinter',
        'tkinter', 'json', 'logging', 'threading',
        'os', 'shutil', 'pathlib', 'datetime',
    ],
}

setup(
    name=APP_NAME,
    version='1.0.1',
    description='Сортировка фотографий и видео по дате создания',
    app=APP,
    data_files=DATA_FILES,
    options={'py2app': OPTIONS},
    setup_requires=['py2app'],
)
PYEOF

# Сборка .app
echo ""
echo "🔨 Сборка .app..."
python3 setup.py py2app --clean

if [ $? -ne 0 ]; then
    echo "❌ Ошибка сборки"
    exit 1
fi

echo ""
echo "============================================="
echo "  ✅ Сборка завершена!"
echo "============================================="
echo ""
echo "📂 .app находится: dist/PhotoSorter.app"
echo ""
echo "🚀 Для запуска: open dist/PhotoSorter.app"
echo ""
echo "📦 Для распространения:"
echo "   1. Откройте папку dist"
echo "   2. Запакуйте PhotoSorter.app в ZIP:"
echo "      cd dist && zip -r PhotoSorter-Mac.zip PhotoSorter.app"
echo ""

# Очистка
rm -f setup.py

echo "🎉 Готово!"