"""
Логика сортировки и перемещения файлов.
КРИТИЧЕСКИ ВАЖНО: никакого удаления файлов — только shutil.move или shutil.copy2.
"""

import hashlib
import logging
import shutil
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional, Any

from photo_sorter.config import (
    MONTH_NAMES_RU,
    PHOTO_DIR_NAME,
    VIDEO_DIR_NAME,
    ENABLE_DEDUP,
    DEDUP_ACTION,
    DEDUP_FOLDER_NAME,
    USE_SOURCE_FOLDER_PREFIX,
    MAX_PARENT_DEPTH_FOR_PREFIX,
)
from photo_sorter.metadata import get_file_date
from photo_sorter.models import FileInfo, FileResult, FileType, SortReport

logger = logging.getLogger(__name__)

# Множество хэшей уже обработанных файлов (для дедупликации)
_seen_hashes: set[str] = set()


def _compute_file_hash(file_path: Path, chunk_size: int = 65536) -> Optional[str]:
    """
    Вычисляет MD5-хэш файла для дедупликации.
    Читает файл чанками, чтобы не загружать большие файлы в память.

    Args:
        file_path: Путь к файлу
        chunk_size: Размер чанка (64 КБ)

    Returns:
        MD5-хэш в виде hex-строки или None при ошибке
    """
    try:
        hasher = hashlib.md5()
        with open(file_path, "rb") as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                hasher.update(chunk)
        return hasher.hexdigest()
    except Exception as e:
        logger.warning(f"Не удалось вычислить хэш для {file_path.name}: {e}")
        return None


def _get_source_prefix(file_info: FileInfo, source_folder: Path) -> str:
    """
    Извлекает префикс из исходной папки для подстановки в имя файла при конфликте.

    Пример:
        source_folder = D:/Фото/Несорт
        file_info.path = D:/Фото/Несорт/Поездка_2022/IMG_001.jpg
        MAX_PARENT_DEPTH = 2
        → префикс = "Поездка_2022"

    Args:
        file_info: Информация о файле
        source_folder: Корневая исходная папка

    Returns:
        Префикс для имени файла или пустую строку
    """
    try:
        relative = file_info.path.parent.relative_to(source_folder)
        parts = relative.parts

        # Берём последние N значимых частей пути
        significant = [p for p in parts if p and p not in ('.', '..')]
        if not significant:
            return ""

        # Берём последние MAX_PARENT_DEPTH_FOR_PREFIX частей
        prefix_parts = significant[-MAX_PARENT_DEPTH_FOR_PREFIX:]
        joined = "_".join(prefix_parts)

        # Очищаем от недопустимых символов
        clean = "".join(c for c in joined if c.isalnum() or c in " _-")
        return clean.strip()

    except (ValueError, AttributeError):
        return ""


def _get_dedup_folder(target_folder: Path) -> Path:
    """
    Возвращает путь к папке для дубликатов.

    Args:
        target_folder: Корневая целевая папка

    Returns:
        Путь к папке Дубликаты
    """
    return target_folder / DEDUP_FOLDER_NAME


def _build_destination_path(
    file_info: FileInfo,
    target_folder: Path,
    file_date: datetime,
    source_folder: Optional[Path] = None,
) -> Path:
    """
    Формирует целевой путь для файла на основе даты и типа.

    Структура: Год/Месяц_год/Тип/файл

    Пример: 2013/Январь_2013/Фото/IMG_001.jpg

    Args:
        file_info: Информация о файле
        target_folder: Корневая целевая папка
        file_date: Дата файла
        source_folder: Корневая исходная папка (для префикса)

    Returns:
        Полный путь к целевому расположению файла
    """
    year = str(file_date.year)
    month_name = MONTH_NAMES_RU[file_date.month]
    month_folder = f"{month_name}_{file_date.year}"

    if file_info.file_type == FileType.PHOTO:
        type_folder = PHOTO_DIR_NAME
    elif file_info.file_type == FileType.VIDEO:
        type_folder = VIDEO_DIR_NAME
    else:
        type_folder = "Прочее"

    return target_folder / year / month_folder / type_folder / file_info.name


def _resolve_conflict(
    dest_path: Path,
    file_info: Optional[FileInfo] = None,
    source_folder: Optional[Path] = None,
) -> Path:
    """
    Если файл с таким именем уже существует, разрешает конфликт.

    Стратегия (при USE_SOURCE_FOLDER_PREFIX=True):
    1. Берём имя исходной подпапки как префикс
    2. Пробуем: source_folder_name_original_name
    3. Если и так занято — добавляем суффикс (N)

    Без префикса (как в v1.0): добавляет суффикс (N).

    Args:
        dest_path: Желаемый целевой путь
        file_info: Информация о файле (нужна для префикса)
        source_folder: Корневая исходная папка

    Returns:
        Путь с разрешённым конфликтом
    """
    if not dest_path.exists():
        return dest_path

    stem = dest_path.stem
    suffix = dest_path.suffix
    parent = dest_path.parent

    if USE_SOURCE_FOLDER_PREFIX and file_info and source_folder:
        # Пробуем с префиксом исходной папки
        prefix = _get_source_prefix(file_info, source_folder)
        if prefix:
            new_name = f"{prefix}_{stem}{suffix}"
            new_path = parent / new_name
            if not new_path.exists():
                return new_path

    # Fallback: суффикс (N)
    counter = 1
    while True:
        new_name = f"{stem} ({counter}){suffix}"
        new_path = parent / new_name
        if not new_path.exists():
            return new_path
        counter += 1


def _move_file(
    source: Path,
    destination: Path,
    copy_mode: bool = False,
    file_info: Optional[FileInfo] = None,
    source_folder: Optional[Path] = None,
) -> FileResult:
    """
    Безопасно перемещает или копирует файл.

    Args:
        source: Исходный путь
        destination: Целевой путь
        copy_mode: Копировать вместо перемещения
        file_info: Информация о файле (для разрешения конфликтов)
        source_folder: Корневая исходная папка (для префикса)

    Returns:
        FileResult с результатом операции
    """
    try:
        # Создаём целевую папку
        destination.parent.mkdir(parents=True, exist_ok=True)

        # Решаем конфликт имён
        final_dest = _resolve_conflict(destination, file_info, source_folder)

        if copy_mode:
            shutil.copy2(str(source), str(final_dest))
            status = "copied"
        else:
            shutil.move(str(source), str(final_dest))
            status = "moved"

        return FileResult(
            source=source,
            destination=final_dest,
            date_found=None,
            exif_dates_found=[],
            status=status,
        )

    except Exception as e:
        logger.error(f"Ошибка при обработке {source.name}: {e}")
        return FileResult(
            source=source,
            destination=None,
            date_found=None,
            exif_dates_found=[],
            status="error",
            error=str(e),
        )


def _is_duplicate(file_info: FileInfo) -> tuple[bool, Optional[str]]:
    """
    Проверяет, является ли файл дубликатом (по MD5-хэшу).

    Args:
        file_info: Информация о файле

    Returns:
        Кортеж (True/False, хэш)
    """
    if not ENABLE_DEDUP:
        return False, None

    file_hash = _compute_file_hash(file_info.path)
    if file_hash is None:
        return False, None  # Не удалось вычислить — пропускаем проверку

    if file_hash in _seen_hashes:
        return True, file_hash

    _seen_hashes.add(file_hash)
    return False, file_hash


def run_sort(
    source_folder: Path,
    target_folder: Path,
    recursive: bool = True,
    dry_run: bool = False,
    copy_mode: bool = False,
    use_ffprobe: bool = True,
    enable_dedup: bool = True,
    progress_callback: Optional[Callable[[str, int, int], None]] = None,
    cancel_flag: Optional[Any] = None,
) -> SortReport:
    """
    Запускает сортировку файлов.

    Args:
        source_folder: Исходная папка
        target_folder: Целевая папка
        recursive: Рекурсивный обход
        dry_run: Пробный прогон (без перемещения)
        copy_mode: Копировать вместо перемещения
        use_ffprobe: Использовать ffprobe для видео
        enable_dedup: Включить дедупликацию по MD5
        progress_callback: Колбэк (текст_статуса, обработано, всего)
        cancel_flag: threading.Event для отмены сортировки

    Returns:
        SortReport с результатами
    """
    from photo_sorter.scanner import scan_folder, count_media_files

    # Сбрасываем множество хэшей при каждом запуске
    global _seen_hashes
    _seen_hashes.clear()

    report = SortReport()

    # Подсчитываем общее количество файлов
    logger.info("Сканирование папки...")
    total_files = count_media_files(source_folder, recursive)
    logger.info(f"Найдено медиа-файлов: {total_files}")

    if total_files == 0:
        return report

    processed = 0

    for file_info in scan_folder(source_folder, recursive):
        # Проверка отмены
        if cancel_flag and cancel_flag.is_set():
            logger.warning("Сортировка прервана пользователем")
            break

        processed += 1
        report.total += 1

        # Обновляем прогресс
        if progress_callback:
            progress_callback(f"Обработка: {file_info.name}", processed, total_files)

        # ── Дедупликация ─────────────────────────────────────────────
        if enable_dedup:
            is_dup, file_hash = _is_duplicate(file_info)
            if is_dup:
                if DEDUP_ACTION == "skip":
                    logger.info(f"⏭️ Дубликат (пропущен): {file_info.name}")
                    report.skipped += 1
                    report.results.append(FileResult(
                        source=file_info.path,
                        destination=None,
                        date_found=None,
                        exif_dates_found=[],
                        status="skipped_dup",
                        error="Дубликат (MD5 совпадает)",
                    ))
                    continue

                elif DEDUP_ACTION == "move":
                    # Перемещаем дубликат в папку Дубликаты/ с сохранением даты
                    file_date, exif_dates = get_file_date(file_info, use_ffprobe=use_ffprobe)
                    dedup_folder = _get_dedup_folder(target_folder)
                    dedup_path = _build_destination_path(file_info, dedup_folder, file_date, source_folder)

                    logger.info(f"📦 Дубликат → Дубликаты/: {file_info.name}")
                    if not dry_run:
                        result = _move_file(
                            source=file_info.path,
                            destination=dedup_path,
                            copy_mode=copy_mode,
                            file_info=file_info,
                            source_folder=source_folder,
                        )
                        result.date_found = file_date
                        result.exif_dates_found = exif_dates
                        report.results.append(result)
                        if result.status in ("moved", "copied"):
                            report.moved += 1
                        elif result.status == "error":
                            report.errors += 1
                    else:
                        report.results.append(FileResult(
                            source=file_info.path,
                            destination=dedup_path,
                            date_found=file_date,
                            exif_dates_found=exif_dates,
                            status="dry_run",
                        ))
                    continue

        # ── Определяем дату файла ───────────────────────────────────
        file_date, exif_dates = get_file_date(file_info, use_ffprobe=use_ffprobe)

        # Формируем целевой путь
        dest_path = _build_destination_path(file_info, target_folder, file_date, source_folder)

        if dry_run:
            # Пробный прогон — ничего не делаем, только логируем
            relative_dest = dest_path.relative_to(target_folder)
            logger.info(f"[DRY-RUN] {file_info.name} → {relative_dest}")

            report.results.append(FileResult(
                source=file_info.path,
                destination=dest_path,
                date_found=file_date,
                exif_dates_found=exif_dates,
                status="dry_run",
            ))
            continue

        # Проверяем, не находится ли файл уже в правильной папке
        try:
            if dest_path.parent == file_info.path.parent:
                logger.info(f"Пропущен (уже в правильной папке): {file_info.name}")
                report.skipped += 1
                report.results.append(FileResult(
                    source=file_info.path,
                    destination=file_info.path,
                    date_found=file_date,
                    exif_dates_found=exif_dates,
                    status="skipped",
                ))
                continue
        except Exception:
            pass

        # Перемещаем или копируем
        result = _move_file(
            source=file_info.path,
            destination=dest_path,
            copy_mode=copy_mode,
            file_info=file_info,
            source_folder=source_folder,
        )

        # Добавляем дату и EXIF данные в результат
        result.date_found = file_date
        result.exif_dates_found = exif_dates

        report.results.append(result)

        if result.status in ("moved", "copied"):
            report.moved += 1
        elif result.status == "error":
            report.errors += 1

    return report