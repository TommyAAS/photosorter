"""
GUI приложение PhotoSorter на CustomTkinter.
Современный стильный интерфейс для сортировки фото и видео.
"""

import logging
import os
import threading
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox
from typing import Optional
import json

import customtkinter as ctk

from photo_sorter.config import APP_NAME, APP_VERSION, APP_GEOMETRY, APP_MIN_WIDTH, APP_MIN_HEIGHT
from photo_sorter.logger import log_action

# Определяем платформу
import platform
IS_MAC = platform.system() == "Darwin"
from photo_sorter.models import SortReport
from photo_sorter.sorter import run_sort
from photo_sorter.scanner import count_media_files

logger = logging.getLogger("photo_sorter")

# ─── Цветовая тема ────────────────────────────────────────────────────

THEME = {
    "bg_dark": "#1a1a2e",
    "bg_card": "#16213e",
    "bg_input": "#0f3460",
    "accent": "#e94560",
    "accent_hover": "#ff6b81",
    "text_primary": "#eaeaea",
    "text_secondary": "#a0a0b0",
    "success": "#2ecc71",
    "warning": "#f39c12",
    "error": "#e74c3c",
    "info": "#3498db",
}

# ─── Файл для сохранения настроек ────────────────────────────────────

SETTINGS_FILE = Path.home() / ".photo_sorter_settings.json"


class PhotoSorterApp(ctk.CTk):
    """Главное окно приложения PhotoSorter."""

    def __init__(self):
        super().__init__()

        # ─── Настройки окна ──────────────────────────────────────────
        self.title(f"{APP_NAME} v{APP_VERSION}")
        self.geometry(APP_GEOMETRY)
        self.minsize(APP_MIN_WIDTH, APP_MIN_HEIGHT)
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")

        # Переменные
        self.source_path = tk.StringVar()
        self.target_path = tk.StringVar()
        self.dry_run_var = tk.BooleanVar(value=False)
        self.copy_mode_var = tk.BooleanVar(value=False)
        self.use_exif_var = tk.BooleanVar(value=True)
        self.recursive_var = tk.BooleanVar(value=True)
        self.use_ffprobe_var = tk.BooleanVar(value=True)
        self.enable_dedup_var = tk.BooleanVar(value=True)

        self._sorting = False
        self._cancel_flag = threading.Event()
        self._files_count = 0
        self._source_files_count = 0

        # ─── Загрузка сохранённых путей ──────────────────────────────
        self._load_settings()

        # ─── Сборка интерфейса ───────────────────────────────────────
        self._build_ui()

        # ─── Привязка клавиш ─────────────────────────────────────────
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        # ─── Таймер для обновления инфо о файлах ────────────────────
        self._update_file_count_timer()

    # ─── Загрузка/сохранение настроек ─────────────────────────────────

    def _load_settings(self):
        """Загружает сохранённые пути из JSON-файла."""
        try:
            if SETTINGS_FILE.exists():
                with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if 'source_path' in data:
                        self.source_path.set(data['source_path'])
                    if 'target_path' in data:
                        self.target_path.set(data['target_path'])
                    if 'recursive' in data:
                        self.recursive_var.set(data['recursive'])
                    if 'copy_mode' in data:
                        self.copy_mode_var.set(data['copy_mode'])
                    if 'dry_run' in data:
                        self.dry_run_var.set(data['dry_run'])
                    if 'use_ffprobe' in data:
                        self.use_ffprobe_var.set(data['use_ffprobe'])
                    if 'enable_dedup' in data:
                        self.enable_dedup_var.set(data['enable_dedup'])
        except Exception:
            pass

    def _save_settings(self):
        """Сохраняет текущие пути в JSON-файл."""
        try:
            data = {
                'source_path': self.source_path.get(),
                'target_path': self.target_path.get(),
                'recursive': self.recursive_var.get(),
                'copy_mode': self.copy_mode_var.get(),
                'dry_run': self.dry_run_var.get(),
                'use_ffprobe': self.use_ffprobe_var.get(),
                'enable_dedup': self.enable_dedup_var.get(),
            }
            with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    # ─── Построение интерфейса ───────────────────────────────────────

    def _build_ui(self):
        """Строит весь интерфейс приложения."""
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # ── Верхняя панель (заголовок) ───────────────────────────────
        self._build_header()

        # ── Основной контент ─────────────────────────────────────────
        main_frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        main_frame.grid(row=1, column=0, sticky="nsew", padx=20, pady=(0, 20))
        main_frame.grid_columnconfigure(0, weight=1)

        # Карточка настроек
        self._build_settings_card(main_frame)

        # Панель информации о файлах
        self._build_info_panel(main_frame)

        # Кнопка запуска
        self._build_start_button(main_frame)

        # LOG
        self._build_log_area(main_frame)

    def _build_header(self):
        """Заголовок приложения."""
        header_frame = ctk.CTkFrame(self, fg_color="transparent", height=80)
        header_frame.grid(row=0, column=0, sticky="ew", padx=20, pady=(20, 10))
        header_frame.grid_columnconfigure(0, weight=1)

        # Иконка и название
        title_frame = ctk.CTkFrame(header_frame, fg_color="transparent")
        title_frame.pack(fill="x")

        ctk.CTkLabel(
            title_frame,
            text="📸",
            font=ctk.CTkFont(size=36),
            text_color=THEME["accent"],
        ).pack(side="left", padx=(0, 10))

        ctk.CTkLabel(
            title_frame,
            text=APP_NAME,
            font=ctk.CTkFont(size=28, weight="bold"),
            text_color=THEME["text_primary"],
        ).pack(side="left")

        ctk.CTkLabel(
            title_frame,
            text=f"v{APP_VERSION}",
            font=ctk.CTkFont(size=14),
            text_color=THEME["text_secondary"],
        ).pack(side="left", padx=(8, 0), pady=(6, 0))

        # Описание
        ctk.CTkLabel(
            header_frame,
            text="Сортировка фотографий и видео по дате создания",
            font=ctk.CTkFont(size=14),
            text_color=THEME["text_secondary"],
        ).pack(anchor="w", padx=(50, 0), pady=(2, 0))

    def _build_settings_card(self, parent):
        """Карточка с настройками сортировки."""
        card = ctk.CTkFrame(parent, fg_color=THEME["bg_card"], corner_radius=16)
        card.grid(row=0, column=0, sticky="nsew", pady=(0, 12))
        card.grid_columnconfigure(1, weight=1)

        # Заголовок карточки
        ctk.CTkLabel(
            card,
            text="⚙️ Настройки сортировки",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=THEME["text_primary"],
        ).grid(row=0, column=0, columnspan=3, sticky="w", padx=24, pady=(24, 16))

        # ── Исходная папка ───────────────────────────────────────────
        ctk.CTkLabel(
            card,
            text="📁 Исходная папка",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=THEME["text_primary"],
        ).grid(row=1, column=0, sticky="w", padx=24, pady=(8, 4))

        source_entry = ctk.CTkEntry(
            card,
            textvariable=self.source_path,
            placeholder_text="Выберите папку с фотографиями...",
            fg_color=THEME["bg_input"],
            border_width=0,
            height=40,
            font=ctk.CTkFont(size=13),
        )
        source_entry.grid(row=2, column=0, columnspan=2, sticky="ew", padx=24, pady=(0, 8))

        ctk.CTkButton(
            card,
            text="Обзор",
            command=lambda: self._browse_folder(self.source_path, True),
            fg_color=THEME["accent"],
            hover_color=THEME["accent_hover"],
            width=90,
            height=40,
            corner_radius=10,
            font=ctk.CTkFont(size=13, weight="bold"),
        ).grid(row=2, column=2, padx=(8, 24), pady=(0, 8))

        # ── Целевая папка ────────────────────────────────────────────
        ctk.CTkLabel(
            card,
            text="📁 Целевая папка",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=THEME["text_primary"],
        ).grid(row=3, column=0, sticky="w", padx=24, pady=(8, 4))

        target_entry = ctk.CTkEntry(
            card,
            textvariable=self.target_path,
            placeholder_text="Выберите папку для отсортированных файлов...",
            fg_color=THEME["bg_input"],
            border_width=0,
            height=40,
            font=ctk.CTkFont(size=13),
        )
        target_entry.grid(row=4, column=0, columnspan=2, sticky="ew", padx=24, pady=(0, 8))

        ctk.CTkButton(
            card,
            text="Обзор",
            command=lambda: self._browse_folder(self.target_path, False),
            fg_color=THEME["accent"],
            hover_color=THEME["accent_hover"],
            width=90,
            height=40,
            corner_radius=10,
            font=ctk.CTkFont(size=13, weight="bold"),
        ).grid(row=4, column=2, padx=(8, 24), pady=(0, 8))

        # ── Разделитель ──────────────────────────────────────────────
        ctk.CTkFrame(
            card, height=1, fg_color=THEME["text_secondary"], corner_radius=0
        ).grid(row=5, column=0, columnspan=3, sticky="ew", padx=24, pady=16)

        # ── Опции ────────────────────────────────────────────────────
        options_frame = ctk.CTkFrame(card, fg_color="transparent")
        options_frame.grid(row=6, column=0, columnspan=3, sticky="ew", padx=24, pady=(0, 20))
        options_frame.grid_columnconfigure(0, weight=1)
        options_frame.grid_columnconfigure(1, weight=1)

        # Левая колонка опций
        left_options = ctk.CTkFrame(options_frame, fg_color="transparent")
        left_options.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        self._create_switch(
            left_options, "⏭️ Пробный прогон (без перемещения)", self.dry_run_var, 0
        )
        self._create_switch(
            left_options, "📋 Копировать (безопасный режим)", self.copy_mode_var, 1
        )
        self._create_switch(
            left_options, "📅 Использовать EXIF для даты", self.use_exif_var, 2
        )

        # Правая колонка опций
        right_options = ctk.CTkFrame(options_frame, fg_color="transparent")
        right_options.grid(row=0, column=1, sticky="nsew", padx=(10, 0))

        self._create_switch(
            right_options, "📂 Рекурсивный обход папок", self.recursive_var, 0
        )
        self._create_switch(
            right_options, "🎬 ffprobe для видео", self.use_ffprobe_var, 1
        )
        self._create_switch(
            right_options, "🔍 Дедупликация (MD5)", self.enable_dedup_var, 2
        )

    def _create_switch(self, parent, text, variable, row):
        """Создаёт переключатель с подписью."""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.grid(row=row, column=0, sticky="ew", pady=4)
        frame.grid_columnconfigure(0, weight=1)

        ctk.CTkSwitch(
            frame,
            text=text,
            variable=variable,
            onvalue=True,
            offvalue=False,
            font=ctk.CTkFont(size=13),
            text_color=THEME["text_primary"],
            progress_color=THEME["accent"],
            button_color=THEME["accent_hover"],
        ).pack(side="left", fill="x", expand=True)

    def _build_info_panel(self, parent):
        """Панель с информацией о найденных файлах."""
        info_card = ctk.CTkFrame(parent, fg_color=THEME["bg_card"], corner_radius=16)
        info_card.grid(row=1, column=0, sticky="ew", pady=(0, 12))
        info_card.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(
            info_card,
            text="📊 Информация:",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=THEME["text_primary"],
        ).grid(row=0, column=0, sticky="w", padx=24, pady=(16, 16))

        self.files_info_label = ctk.CTkLabel(
            info_card,
            text="Нажмите 'Обзор' для выбора папки",
            font=ctk.CTkFont(size=13),
            text_color=THEME["text_secondary"],
            anchor="w",
        )
        self.files_info_label.grid(row=0, column=1, sticky="ew", padx=(0, 24), pady=(16, 16))

    def _build_start_button(self, parent):
        """Кнопка запуска сортировки."""
        self.start_button = ctk.CTkButton(
            parent,
            text="🚀 ЗАПУСТИТЬ СОРТИРОВКУ",
            command=self._start_sorting,
            fg_color=THEME["accent"],
            hover_color=THEME["accent_hover"],
            height=56,
            corner_radius=16,
            font=ctk.CTkFont(size=18, weight="bold"),
        )
        self.start_button.grid(row=2, column=0, sticky="ew", pady=(0, 12))

        self.cancel_button = ctk.CTkButton(
            parent,
            text="⏹ ОТМЕНА",
            command=self._cancel_sorting,
            fg_color="transparent",
            hover_color="#333",
            height=40,
            corner_radius=12,
            font=ctk.CTkFont(size=14, weight="bold"),
            border_width=2,
            border_color=THEME["error"],
            text_color=THEME["error"],
        )
        self.cancel_button.grid(row=3, column=0, sticky="ew", pady=(0, 12))
        self.cancel_button.grid_remove()

    def _build_log_area(self, parent):
        """Область лога и прогресса."""
        # Карточка лога
        log_card = ctk.CTkFrame(parent, fg_color=THEME["bg_card"], corner_radius=16)
        log_card.grid(row=4, column=0, sticky="nsew")
        log_card.grid_columnconfigure(0, weight=1)
        log_card.grid_rowconfigure(2, weight=1)

        # Заголовок
        ctk.CTkLabel(
            log_card,
            text="📋 Прогресс и результаты",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=THEME["text_primary"],
        ).grid(row=0, column=0, sticky="w", padx=24, pady=(24, 8))

        # Прогресс-бар
        progress_frame = ctk.CTkFrame(log_card, fg_color="transparent")
        progress_frame.grid(row=1, column=0, sticky="ew", padx=24, pady=(8, 8))
        progress_frame.grid_columnconfigure(0, weight=1)

        self.progress_bar = ctk.CTkProgressBar(
            progress_frame,
            fg_color=THEME["bg_input"],
            progress_color=THEME["accent"],
            height=8,
            corner_radius=4,
        )
        self.progress_bar.pack(fill="x", side="left", expand=True)

        self.progress_label = ctk.CTkLabel(
            progress_frame,
            text="0%",
            font=ctk.CTkFont(size=12),
            text_color=THEME["text_secondary"],
            width=45,
        )
        self.progress_label.pack(side="right", padx=(8, 0))

        # Текущий статус
        self.status_label = ctk.CTkLabel(
            log_card,
            text="Готов к работе",
            font=ctk.CTkFont(size=13),
            text_color=THEME["text_secondary"],
            anchor="w",
        )
        self.status_label.grid(row=2, column=0, sticky="ew", padx=24, pady=(0, 8))

        # Текстовое поле для лога
        log_frame = ctk.CTkFrame(log_card, fg_color=THEME["bg_input"], corner_radius=12)
        log_frame.grid(row=3, column=0, sticky="nsew", padx=24, pady=(0, 24))
        log_frame.grid_columnconfigure(0, weight=1)
        log_frame.grid_rowconfigure(0, weight=1)

        self.log_text = ctk.CTkTextbox(
            log_frame,
            fg_color="transparent",
            text_color=THEME["text_primary"],
            font=ctk.CTkFont(size=12, family="Consolas"),
            wrap="word",
            border_width=0,
        )
        self.log_text.grid(row=0, column=0, sticky="nsew", padx=12, pady=12)

        # Нижняя панель с кнопками
        button_frame = ctk.CTkFrame(log_card, fg_color="transparent")
        button_frame.grid(row=5, column=0, sticky="ew", padx=24, pady=(0, 20))
        button_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkButton(
            button_frame,
            text="📂 Открыть целевую папку",
            command=self._open_target_folder,
            fg_color="transparent",
            hover_color="#333",
            height=32,
            corner_radius=8,
            font=ctk.CTkFont(size=12),
            border_width=1,
            border_color=THEME["text_secondary"],
            text_color=THEME["text_secondary"],
        ).pack(side="left")

        ctk.CTkButton(
            button_frame,
            text="📋 Копировать лог",
            command=self._copy_log,
            fg_color="transparent",
            hover_color="#333",
            height=32,
            corner_radius=8,
            font=ctk.CTkFont(size=12),
            border_width=1,
            border_color=THEME["text_secondary"],
            text_color=THEME["text_secondary"],
        ).pack(side="right", padx=(8, 0))

        ctk.CTkButton(
            button_frame,
            text="🗑 Очистить лог",
            command=self._clear_log,
            fg_color="transparent",
            hover_color="#333",
            height=32,
            corner_radius=8,
            font=ctk.CTkFont(size=12),
            border_width=1,
            border_color=THEME["text_secondary"],
            text_color=THEME["text_secondary"],
        ).pack(side="right")

    # ─── Методы ───────────────────────────────────────────────────────

    def _browse_folder(self, var: tk.StringVar, is_source: bool):
        """Открывает диалог выбора папки."""
        folder = filedialog.askdirectory(title="Выберите папку")
        if folder:
            var.set(folder)
            self._log(f"📁 Выбрана папка: {folder}")
            self._save_settings()
            if is_source:
                # Запускаем подсчёт файлов в фоне
                self._update_file_count_async()

    def _update_file_count_async(self):
        """Асинхронно подсчитывает файлы в исходной папке."""
        def count():
            source = self.source_path.get().strip()
            if source and Path(source).exists():
                try:
                    count = count_media_files(Path(source), self.recursive_var.get())
                    self._source_files_count = count
                    self.after(0, lambda: self.files_info_label.configure(
                        text=f"📄 Найдено медиа-файлов: {count}"
                    ))
                except Exception as e:
                    self.after(0, lambda: self.files_info_label.configure(
                        text=f"⚠️ Ошибка сканирования: {e}"
                    ))
            else:
                self.after(0, lambda: self.files_info_label.configure(
                    text="📂 Папка не выбрана или не существует"
                ))

        thread = threading.Thread(target=count, daemon=True)
        thread.start()

    def _update_file_count_timer(self):
        """Периодически обновляет информацию о файлах (каждые 2 сек при изменении пути)."""
        if not self._sorting:
            self._update_file_count_async()
        self.after(2000, self._update_file_count_timer)

    def _log(self, message: str, level: str = "INFO"):
        """Добавляет сообщение в лог с цветовой маркировкой."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        level_icons = {
            "INFO": "",
            "WARN": "⚠️ ",
            "ERROR": "❌ ",
            "SUCCESS": "✅ ",
            "MOVE": "📦 ",
            "DRY": "🔍 ",
        }
        icon = level_icons.get(level, "")
        self.log_text.insert("end", f"[{timestamp}] {icon}{message}\n")
        self.log_text.see("end")
        self.update_idletasks()

    def _clear_log(self):
        """Очищает лог."""
        self.log_text.delete("1.0", "end")

    def _copy_log(self):
        """Копирует содержимое лога в буфер обмена."""
        log_content = self.log_text.get("1.0", "end-1c")
        if log_content:
            self.clipboard_clear()
            self.clipboard_append(log_content)
            self._log("📋 Лог скопирован в буфер обмена")

    def _open_folder(self, folder_path: str):
        """Открывает папку в штатном файловом менеджере (Windows/macOS/Linux)."""
        import subprocess
        try:
            if IS_MAC:
                subprocess.run(['open', folder_path], check=True)
            elif platform.system() == "Windows":
                os.startfile(folder_path)
            else:  # Linux
                subprocess.run(['xdg-open', folder_path], check=True)
        except Exception as e:
            self._log(f"⚠️ Не удалось открыть папку: {e}", "WARN")

    def _open_target_folder(self):
        """Открывает целевую папку в файловом менеджере."""
        target = self.target_path.get().strip()
        if target and Path(target).exists():
            self._open_folder(target)
            self._log(f"📂 Открыта папка: {target}")
        else:
            self._log("⚠️ Целевая папка не существует", "WARN")

    def _update_progress(self, status_text: str, processed: int, total: int):
        """Обновляет прогресс-бар и статус."""
        if total > 0:
            progress = processed / total
            self.progress_bar.set(progress)
            self.progress_label.configure(text=f"{int(progress * 100)}%")
        self.status_label.configure(text=status_text)
        self._log(f"  → {status_text}")
        self.update_idletasks()

    def _start_sorting(self):
        """Запускает сортировку в отдельном потоке."""
        # Валидация
        source = self.source_path.get().strip()
        target = self.target_path.get().strip()

        if not source:
            messagebox.showwarning("Внимание", "Выберите исходную папку!")
            return

        if not target:
            messagebox.showwarning("Внимание", "Выберите целевую папку!")
            return

        source_path = Path(source)
        target_path = Path(target)

        if not source_path.exists():
            messagebox.showerror("Ошибка", "Исходная папка не существует!")
            return

        if source == target:
            messagebox.showwarning(
                "Внимание",
                "Исходная и целевая папки совпадают!\n"
                "Это может привести к проблемам. Укажите разные папки."
            )
            return

        # Подтверждение перед реальным перемещением
        if not self.dry_run_var.get() and not self.copy_mode_var.get():
            file_count = self._source_files_count
            msg = f"Будет перемещено до {file_count} файлов.\n\n"
            msg += "Исходная папка: {}\n".format(source)
            msg += "Целевая папка:  {}\n\n".format(target)
            msg += "Файлы будут перемещены (не скопированы).\n"
            msg += "Продолжить?"

            if not messagebox.askyesno("Подтверждение сортировки", msg):
                self._log("⏹ Сортировка отменена пользователем")
                return

        # Блокируем кнопки
        self._sorting = True
        self._cancel_flag.clear()
        self.start_button.configure(state="disabled", text="⏳ СОРТИРУЮ...")
        self.cancel_button.grid()
        self.cancel_button.configure(state="normal", text="⏹ ОТМЕНА")

        self._log("=" * 60)
        self._log(f"🚀 ЗАПУСК СОРТИРОВКИ")
        self._log(f"  Источник: {source}")
        self._log(f"  Цель: {target}")
        self._log(f"  Dry-run: {self.dry_run_var.get()}")
        self._log(f"  Копировать: {self.copy_mode_var.get()}")
        self._log(f"  EXIF: {self.use_exif_var.get()}")
        self._log(f"  Рекурсивно: {self.recursive_var.get()}")
        self._log(f"  ffprobe: {self.use_ffprobe_var.get()}")
        self._log("=" * 60)

        # Запускаем в отдельном потоке
        thread = threading.Thread(
            target=self._sorting_thread,
            args=(source_path, target_path),
            daemon=True,
        )
        thread.start()

    def _sorting_thread(self, source: Path, target: Path):
        """Выполняет сортировку в фоновом потоке."""
        try:
            report = run_sort(
                source_folder=source,
                target_folder=target,
                recursive=self.recursive_var.get(),
                dry_run=self.dry_run_var.get(),
                copy_mode=self.copy_mode_var.get(),
                use_ffprobe=self.use_ffprobe_var.get(),
                enable_dedup=self.enable_dedup_var.get(),
                progress_callback=self._update_progress,
                cancel_flag=self._cancel_flag,
            )

            # Показываем результат в главном потоке
            self.after(0, self._show_report, report)

        except Exception as e:
            self.after(0, lambda: self._log(f"❌ Критическая ошибка: {e}", "ERROR"))
            self.after(0, self._finish_sorting)

    def _show_report(self, report: SortReport):
        """Отображает отчёт о сортировке."""
        self._log("=" * 60)
        self._log(f"📊 ОТЧЁТ О СОРТИРОВКЕ")
        self._log(f"  📄 Всего найдено: {report.total}")
        self._log(f"  ✅ Перемещено/скопировано: {report.moved}")
        self._log(f"  ⏭️ Пропущено: {report.skipped}")
        self._log(f"  ❌ Ошибок: {report.errors}")

        if self._cancel_flag.is_set():
            self._log("⏹ Сортировка была прервана пользователем")

        if report.errors > 0:
            self._log("  ⚠️ Файлы с ошибками:")
            for result in report.results:
                if result.status == "error":
                    self._log(f"    - {result.source.name}: {result.error}")

        self._log("=" * 60)

        if self.dry_run_var.get():
            self._log("🔍 Режим пробного прогона завершён. Файлы не перемещались.")
            messagebox.showinfo(
                "Пробный прогон завершён",
                f"Найдено файлов: {report.total}\n"
                f"Будет перемещено: {report.moved}\n"
                f"Пропущено: {report.skipped}\n"
                f"Ошибок: {report.errors}\n\n"
                "Отключите 'Пробный прогон' и запустите снова для реальной сортировки."
            )
        else:
            if self._cancel_flag.is_set():
                self._log("⏹ Сортировка прервана!")
                messagebox.showinfo(
                    "Сортировка прервана",
                    f"✅ Перемещено/скопировано: {report.moved}\n"
                    f"⏭️ Пропущено: {report.skipped}\n"
                    f"❌ Ошибок: {report.errors}\n\n"
                    "Часть файлов уже отсортирована."
                )
            else:
                self._log("✅ Сортировка завершена!")

                # Автоматически открываем целевую папку
                if report.moved > 0 and not self.dry_run_var.get():
                    self._log("📂 Открываю целевую папку...")
                    target_path = self.target_path.get().strip()
                    if target_path:
                        self._open_folder(target_path)

                messagebox.showinfo(
                    "Сортировка завершена!",
                    f"✅ Перемещено/скопировано: {report.moved}\n"
                    f"⏭️ Пропущено: {report.skipped}\n"
                    f"❌ Ошибок: {report.errors}"
                )

        self._finish_sorting()

    def _finish_sorting(self):
        """Возвращает интерфейс в исходное состояние."""
        self.start_button.configure(state="normal", text="🚀 ЗАПУСТИТЬ СОРТИРОВКУ")
        self.cancel_button.grid_remove()
        self._sorting = False
        self.progress_bar.set(1.0)
        self.progress_label.configure(text="100%")
        self.status_label.configure(text="✅ Сортировка завершена")

    def _cancel_sorting(self):
        """Отменяет сортировку."""
        self._cancel_flag.set()
        self._log("⏹ ОТМЕНА: завершение текущей операции...")
        self.cancel_button.configure(state="disabled", text="⏳ ОТМЕНЯЮ...")

    def _on_close(self):
        """Обработка закрытия окна."""
        self._save_settings()
        if self._sorting:
            if messagebox.askyesno("Подтверждение", "Сортировка ещё выполняется. Завершить?"):
                self._cancel_sorting()
                self.destroy()
        else:
            self.destroy()


def run_app():
    """Запускает GUI приложение."""
    app = PhotoSorterApp()
    app.mainloop()