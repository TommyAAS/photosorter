"""
Логирование для PhotoSorter.
Поддерживает цветной вывод в консоль и запись в файл.
"""

import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

# ANSI-цвета для консоли (Windows поддерживает через colorama или NativeANSI)
RESET = "\033[0m"
BOLD = "\033[1m"
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
BLUE = "\033[94m"
CYAN = "\033[96m"
MAGENTA = "\033[95m"
WHITE = "\033[97m"
DIM = "\033[2m"


class ColoredFormatter(logging.Formatter):
    """Форматтер с цветами для консоли."""

    LEVEL_COLORS = {
        logging.DEBUG: DIM + WHITE,
        logging.INFO: GREEN,
        logging.WARNING: YELLOW + BOLD,
        logging.ERROR: RED + BOLD,
        logging.CRITICAL: RED + BOLD,
    }

    LEVEL_ICONS = {
        "MOVE": "📦",
        "MKDIR": "📁",
        "SKIP": "⏭️",
        "ERROR": "❌",
        "DRY_RUN": "🔍",
        "INFO": "ℹ️",
        "WARNING": "⚠️",
    }

    def format(self, record: logging.LogRecord) -> str:
        # Добавляем иконку для action-логов
        if hasattr(record, 'action'):
            icon = self.LEVEL_ICONS.get(record.action, "")
            record.msg = f"{icon} {record.msg}"

        color = self.LEVEL_COLORS.get(record.levelno, RESET)
        timestamp = datetime.fromtimestamp(record.created).strftime("%Y-%m-%d %H:%M:%S")

        if record.levelno == logging.DEBUG:
            return f"{DIM}[{timestamp}]{RESET} {color}[{record.levelname}]{RESET} {DIM}{record.msg}{RESET}"
        elif record.levelno >= logging.ERROR:
            return f"{color}[{timestamp}] [{record.levelname}]{RESET} {record.msg}"
        else:
            return f"{color}[{timestamp}]{RESET} {record.msg}"


class FileFormatter(logging.Formatter):
    """Форматтер для записи в файл (без цветов)."""

    def format(self, record: logging.LogRecord) -> str:
        timestamp = datetime.fromtimestamp(record.created).strftime("%Y-%m-%d %H:%M:%S")
        action = getattr(record, 'action', record.levelname)
        return f"[{timestamp}] {action}: {record.msg}"


class ActionLoggerAdapter(logging.LoggerAdapter):
    """Адаптер логгера для передачи action."""

    def process(self, msg, kwargs):
        if 'extra' in kwargs:
            kwargs['extra']['action'] = kwargs.get('action', 'INFO')
        return msg, kwargs


def setup_logger(log_file: Optional[Path] = None, verbose: bool = False) -> logging.Logger:
    """
    Настраивает и возвращает логгер приложения.
    
    Args:
        log_file: Путь к файлу лога (опционально)
        verbose: Включить DEBUG-вывод
    
    Returns:
        Настроенный логгер
    """
    logger = logging.getLogger("photo_sorter")
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)
    
    # Очищаем старые хендлеры
    logger.handlers.clear()
    
    # Консольный хендлер (с цветами)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.DEBUG if verbose else logging.INFO)
    console_handler.setFormatter(ColoredFormatter())
    logger.addHandler(console_handler)
    
    # Файловый хендлер (без цветов)
    if log_file:
        log_file = Path(log_file)
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(FileFormatter())
        logger.addHandler(file_handler)
    
    return logger


def log_action(logger: logging.Logger, action: str, message: str, *args, **kwargs):
    """
    Логирует действие с указанным типом.
    
    Args:
        logger: Логгер
        action: Тип действия (MOVE, MKDIR, SKIP, ERROR, DRY_RUN)
        message: Сообщение
    """
    level = logging.ERROR if action == "ERROR" else logging.INFO
    logger.log(level, message, extra={'action': action}, *args, **kwargs)