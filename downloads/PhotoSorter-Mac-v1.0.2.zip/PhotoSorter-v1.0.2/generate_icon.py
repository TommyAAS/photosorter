"""
Генератор иконки для PhotoSorter.
Создаёт .ico (Windows), .icns (macOS) и .png файлы с помощью Pillow.
"""

from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import sys
import os
import subprocess
import platform


def create_camera_icon(size: int) -> Image.Image:
    """
    Рисует иконку камеры на прозрачном фоне.

    Args:
        size: Размер иконки в пикселях

    Returns:
        RGBA Image
    """
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Цвета (в стиле темы PhotoSorter)
    accent = (233, 69, 96)   # #e94560
    dark = (26, 26, 46)      # #1a1a2e
    white = (234, 234, 234)  # #eaeaea

    margin = size // 8
    body_top = size // 4
    body_bottom = size - margin
    body_left = margin
    body_right = size - margin

    # Основной корпус камеры
    draw.rounded_rectangle(
        [body_left, body_top, body_right, body_bottom],
        radius=size // 10,
        fill=dark,
        outline=accent,
        width=max(2, size // 16),
    )

    # Верхняя часть (вспышка)
    flash_width = size // 3
    flash_height = size // 12
    flash_left = size // 2 - flash_width // 2
    draw.rectangle(
        [flash_left, body_top - flash_height, flash_left + flash_width, body_top],
        fill=accent,
    )

    # Объектив (круг)
    lens_center = (size // 2, (body_top + body_bottom) // 2)
    lens_radius = size // 6
    draw.ellipse(
        [
            lens_center[0] - lens_radius,
            lens_center[1] - lens_radius,
            lens_center[0] + lens_radius,
            lens_center[1] + lens_radius,
        ],
        fill=accent,
        outline=white,
        width=max(1, size // 20),
    )

    # Блик на объективе
    highlight_radius = lens_radius // 3
    draw.ellipse(
        [
            lens_center[0] - highlight_radius,
            lens_center[1] - highlight_radius,
            lens_center[0] + highlight_radius,
            lens_center[1] + highlight_radius,
        ],
        fill=white,
    )

    return img


def generate_ico(output_path: Path):
    """Генерирует .ico файл для Windows."""
    sizes = [16, 32, 48, 64, 128, 256]
    images = [create_camera_icon(s) for s in sizes]

    # ICO сохраняем несколько размеров
    image_versions = []
    for s, img in zip(sizes, images):
        image_versions.append(img)

    output_path = output_path.with_suffix(".ico")
    image_versions[0].save(
        output_path,
        format="ICO",
        sizes=[(s, s) for s in sizes],
        append_images=image_versions[1:],
    )
    print(f"✅ ICO иконка создана: {output_path}")
    return output_path


def generate_png(output_path: Path, size: int = 256):
    """Генерирует .png иконку."""
    img = create_camera_icon(size)
    output_path = output_path.with_suffix(".png")
    img.save(output_path, "PNG")
    print(f"✅ PNG иконка создана: {output_path}")
    return output_path


def generate_icns(output_path: Path):
    """
    Генерирует .icns файл для macOS.
    Использует iconutil (встроен в macOS) или создаёт PNG как fallback.
    """
    # Создаём временную папку с наборами иконок
    iconset_dir = output_path.parent / "PhotoSorter.iconset"
    iconset_dir.mkdir(parents=True, exist_ok=True)

    # macOS требует конкретные размеры
    size_map = {
        "icon_16x16.png": 16,
        "icon_16x16@2x.png": 32,
        "icon_32x32.png": 32,
        "icon_32x32@2x.png": 64,
        "icon_128x128.png": 128,
        "icon_128x128@2x.png": 256,
        "icon_256x256.png": 256,
        "icon_256x256@2x.png": 512,
        "icon_512x512.png": 512,
        "icon_512x512@2x.png": 1024,
    }

    for name, size in size_map.items():
        img = create_camera_icon(size)
        img.save(iconset_dir / name)

    # Пробуем сконвертировать через iconutil (macOS)
    icns_path = output_path.with_suffix(".icns")
    try:
        if platform.system() == "Darwin":
            subprocess.run(
                ["iconutil", "-c", "icns", str(iconset_dir), "-o", str(icns_path)],
                check=True, capture_output=True
            )
            print(f"✅ ICNS иконка создана: {icns_path}")

            # Очищаем временную папку
            import shutil
            shutil.rmtree(iconset_dir, ignore_errors=True)

            return icns_path
        else:
            print(f"⚠️  Не удалось создать .icns (не macOS). Создан PNG как fallback.")
            print(f"   Иконки для .icns сохранены в: {iconset_dir}")
            print(f"   На macOS запустите: iconutil -c icns '{iconset_dir}' -o '{icns_path}'")
            return None

    except (FileNotFoundError, subprocess.CalledProcessError):
        print(f"⚠️  iconutil не найден. Создан PNG как fallback.")
        print(f"   Иконки для .icns сохранены в: {iconset_dir}")
        return None


def main():
    """Главная функция генератора."""
    output_dir = Path(__file__).parent
    name = "icon"

    # Определяем, какие форматы генерировать
    generate_png(output_dir / name)  # Всегда PNG

    if "--ico" in sys.argv or "--all" in sys.argv or platform.system() == "Windows":
        generate_ico(output_dir / name)

    if "--icns" in sys.argv or "--all" in sys.argv or platform.system() == "Darwin":
        generate_icns(output_dir / name)

    print()
    print("🎨 Доступные иконки:")
    for f in sorted(output_dir.glob("icon.*")):
        size = f.stat().st_size
        print(f"   {f.name} ({size / 1024:.1f} KB)")

    print()
    print("💡 Для сборки .app на macOS: ./build_mac_app.sh")


if __name__ == "__main__":
    main()