"""
Генератор тестовых данных для PhotoSorter.
Создаёт временные папки с тестовыми фото/видео для проверки сортировки.
"""

import os
import shutil
import tempfile
from pathlib import Path
from datetime import datetime
from typing import Optional

# Тестовые файлы — создаём пустые заглушки с разными расширениями
# и устанавливаем им нужную дату через mtime

TEST_FILES = [
    # (имя, расширение, год, месяц, день)
    ("photo_2022_01", ".jpg", 2022, 1, 15),
    ("photo_2022_06", ".jpeg", 2022, 6, 20),
    ("photo_2022_12", ".png", 2022, 12, 31),
    ("photo_2013_03", ".jpg", 2013, 3, 10),
    ("photo_2013_04", ".jpg", 2013, 4, 5),
    ("photo_2005_07", ".jpg", 2005, 7, 14),
    ("photo_2005_07_v2", ".png", 2005, 7, 20),
    ("photo_2024_01", ".jpg", 2024, 1, 1),
    ("photo_2024_11", ".webp", 2024, 11, 15),
    ("photo_1999_12", ".gif", 1999, 12, 25),
    # Видео
    ("video_2022_01", ".mp4", 2022, 1, 15),
    ("video_2013_03", ".mov", 2013, 3, 10),
    ("video_2005_07", ".avi", 2005, 7, 14),
    # Дубликаты имён (для проверки конфликтов — в РАЗНЫХ подпапках, но после сортировки попадут в одну папку)
    ("duplicate_test/vacation_2022", ".jpg", 2022, 1, 15),   # оригинал в подпапке duplicate_test
    ("duplicate_test_2/vacation_2022", ".jpg", 2022, 1, 15),  # дубликат в другой подпапке
    # Системные файлы (должны игнорироваться)
    ("Thumbs", ".db", 2022, 1, 1),
    (".DS_Store", "", 2022, 1, 1),
    # Не-медиа файлы (должны игнорироваться)
    ("document", ".txt", 2022, 1, 1),
    ("readme", ".md", 2022, 1, 1),
    ("script", ".py", 2022, 1, 1),
    # Файлы в подпапках (для теста рекурсии)
    ("nested/nested_photo", ".jpg", 2021, 5, 10),
    ("nested/deep/deep_photo", ".jpg", 2020, 8, 22),
    # Файлы с кириллицей
    ("отпуск_2022", ".jpg", 2022, 7, 7),
    ("семейное_фото", ".png", 2021, 12, 31),
    # Файлы со спецсимволами
    ("photo#1", ".jpg", 2023, 3, 3),
    ("photo%final", ".jpeg", 2023, 6, 6),
    ("photo&family", ".jpg", 2023, 9, 9),
]


class TestDataGenerator:
    """Генератор тестовых данных."""

    def __init__(self, base_dir: Optional[Path] = None):
        self.base_dir = base_dir or Path(tempfile.mkdtemp(prefix="photo_sorter_test_"))
        self.source_dir = self.base_dir / "source"
        self.target_dir = self.base_dir / "target"

    def create(self) -> None:
        """Создаёт тестовую структуру папок и файлов."""
        self.source_dir.mkdir(parents=True, exist_ok=True)
        self.target_dir.mkdir(parents=True, exist_ok=True)

        for name, ext, year, month, day in TEST_FILES:
            # Создаём подпапки если нужно
            file_path = self.source_dir / f"{name}{ext}"
            file_path.parent.mkdir(parents=True, exist_ok=True)

            # Создаём пустой файл
            file_path.touch()

            # Устанавливаем дату модификации
            dt = datetime(year, month, day, 12, 0, 0)
            ts = dt.timestamp()
            os.utime(file_path, (ts, ts))

        print(f"📁 Тестовые данные созданы в: {self.source_dir}")
        print(f"   Целевая папка: {self.target_dir}")
        print(f"   Всего файлов: {len(list(self.source_dir.rglob('*')))}")

    def cleanup(self) -> None:
        """Удаляет тестовые данные."""
        shutil.rmtree(self.base_dir, ignore_errors=True)
        print(f"🗑 Тестовые данные удалены: {self.base_dir}")

    def count_files(self, directory: Optional[Path] = None) -> int:
        """Подсчитывает количество файлов в директории."""
        dir_path = directory or self.source_dir
        return sum(1 for f in dir_path.rglob("*") if f.is_file())


if __name__ == "__main__":
    gen = TestDataGenerator()
    gen.create()

    print("\n📂 Структура:")
    for f in sorted(gen.source_dir.rglob("*")):
        if f.is_file():
            rel = f.relative_to(gen.source_dir)
            mtime = datetime.fromtimestamp(f.stat().st_mtime)
            print(f"   {rel}  ({mtime.strftime('%Y-%m-%d')})")

    print(f"\n✅ Всего медиа-файлов: {gen.count_files()}")