"""
Полный прогон тестов PhotoSorter.
Запускает модульные и интеграционные тесты, генерирует отчёт.
"""

import sys
import os
import shutil
from pathlib import Path
from datetime import datetime

# Добавляем корень проекта в PYTHONPATH
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from photo_sorter.config import (
    PHOTO_EXTENSIONS, VIDEO_EXTENSIONS, ALL_MEDIA_EXTENSIONS,
    IGNORED_FILES, MONTH_NAMES_RU, MIN_VALID_YEAR,
    PHOTO_DIR_NAME, VIDEO_DIR_NAME,
)
from photo_sorter.models import FileInfo, FileType, SortReport
from photo_sorter.scanner import scan_folder, count_media_files
from photo_sorter.metadata import (
    _parse_exif_date, _is_valid_date, get_date_from_mtime,
    get_date_from_exif, get_file_date,
)
from photo_sorter.sorter import _build_destination_path, _resolve_conflict, run_sort
from photo_sorter.tests.generate_test_data import TestDataGenerator, TEST_FILES


# ─── Счётчик тестов ──────────────────────────────────────────────────

class TestRunner:
    """Запускает тесты и собирает статистику."""

    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.errors = []
        self.start_time = None

    def test(self, name: str, func, expected=None):
        """Запускает один тест."""
        try:
            result = func()
            if expected is not None and result != expected:
                raise AssertionError(f"Ожидалось {expected!r}, получено {result!r}")
            self.passed += 1
            print(f"  ✅ {name}")
        except Exception as e:
            self.failed += 1
            self.errors.append((name, str(e)))
            print(f"  ❌ {name}: {e}")

    def run_all(self):
        """Запускает все тесты."""
        self.start_time = datetime.now()
        print("=" * 70)
        print("  📸 PHOTOSORTER — ПОЛНОЕ ТЕСТИРОВАНИЕ v1.0.0")
        print("=" * 70)
        print()

        self._test_config()
        self._test_models()
        self._test_metadata_parsing()
        self._test_scanner()
        self._test_sorter()
        self._test_integration()
        self._test_security()

        self._print_report()

    def _test_config(self):
        """Тесты config.py."""
        print("📁 1. КОНФИГУРАЦИЯ (config.py)")
        print("-" * 40)

        self.test("Фото: .jpg в PHOTO_EXTENSIONS",
                  lambda: '.jpg' in PHOTO_EXTENSIONS, True)
        self.test("Фото: .png в PHOTO_EXTENSIONS",
                  lambda: '.png' in PHOTO_EXTENSIONS, True)
        self.test("Фото: .heic в PHOTO_EXTENSIONS",
                  lambda: '.heic' in PHOTO_EXTENSIONS, True)
        self.test("Видео: .mp4 в VIDEO_EXTENSIONS",
                  lambda: '.mp4' in VIDEO_EXTENSIONS, True)
        self.test("Видео: .mov в VIDEO_EXTENSIONS",
                  lambda: '.mov' in VIDEO_EXTENSIONS, True)
        self.test("ALL_MEDIA_EXTENSIONS содержит .jpg",
                  lambda: '.jpg' in ALL_MEDIA_EXTENSIONS, True)
        self.test("ALL_MEDIA_EXTENSIONS содержит .mp4",
                  lambda: '.mp4' in ALL_MEDIA_EXTENSIONS, True)
        self.test("ALL_MEDIA_EXTENSIONS НЕ содержит .txt",
                  lambda: '.txt' not in ALL_MEDIA_EXTENSIONS, True)
        self.test("IGNORED_FILES содержит thumbs.db",
                  lambda: 'thumbs.db' in IGNORED_FILES, True)
        self.test("IGNORED_FILES содержит .ds_store",
                  lambda: '.ds_store' in IGNORED_FILES, True)
        self.test("Названия месяцев: 12 элементов + пустой 0-й",
                  lambda: len(MONTH_NAMES_RU) == 13, True)
        self.test("Месяц 1 = Январь",
                  lambda: MONTH_NAMES_RU[1] == "Январь", True)
        self.test("Месяц 12 = Декабрь",
                  lambda: MONTH_NAMES_RU[12] == "Декабрь", True)
        self.test("MIN_VALID_YEAR == 1980",
                  lambda: MIN_VALID_YEAR == 1980, True)
        self.test("PHOTO_DIR_NAME = Фото",
                  lambda: PHOTO_DIR_NAME == "Фото", True)
        self.test("VIDEO_DIR_NAME = Видео",
                  lambda: VIDEO_DIR_NAME == "Видео", True)
        print()

    def _test_models(self):
        """Тесты models.py."""
        print("📁 2. МОДЕЛИ (models.py)")
        print("-" * 40)

        self.test("FileType.PHOTO существует",
                  lambda: FileType.PHOTO.value == "photo", True)
        self.test("FileType.VIDEO существует",
                  lambda: FileType.VIDEO.value == "video", True)
        self.test("FileInfo.name возвращает имя",
                  lambda: FileInfo(path=Path("test.jpg"), file_type=FileType.PHOTO, extension=".jpg").name == "test.jpg", True)
        self.test("SortReport пустой",
                  lambda: SortReport().total == 0, True)
        self.test("SortReport суммирует moved",
                  lambda: SortReport(moved=5).moved == 5, True)
        print()

    def _test_metadata_parsing(self):
        """Тесты metadata.py."""
        print("📁 3. ПАРСИНГ ДАТЫ (metadata.py)")
        print("-" * 40)

        # _parse_exif_date
        dt = _parse_exif_date("2022:03:15 14:30:00")
        self.test("_parse_exif_date: YYYY:MM:DD HH:MM:SS",
                  lambda: dt is not None and dt.year == 2022, True)

        dt = _parse_exif_date("2022-03-15 14:30:00")
        self.test("_parse_exif_date: YYYY-MM-DD HH:MM:SS",
                  lambda: dt is not None and dt.year == 2022, True)

        self.test("_parse_exif_date: пустая строка → None",
                  lambda: _parse_exif_date("") is None, True)
        self.test("_parse_exif_date: invalid → None",
                  lambda: _parse_exif_date("not_a_date") is None, True)

        # _is_valid_date
        from datetime import datetime as dt2
        self.test("_is_valid_date: 1990-01-01 → True",
                  lambda: _is_valid_date(dt2(1990, 1, 1)), True)
        self.test("_is_valid_date: 1970-01-01 → False (< 1980)",
                  lambda: _is_valid_date(dt2(1970, 1, 1)), False)
        self.test("_is_valid_date: None → False",
                  lambda: _is_valid_date(None), False)

        # Будущая дата
        from datetime import timedelta
        far_future = dt2.now() + timedelta(days=3)
        self.test("_is_valid_date: +3 дня → False",
                  lambda: _is_valid_date(far_future), False)

        # Тест с реальным файлом
        test_file = Path(__file__)
        dt_mtime = get_date_from_mtime(test_file)
        self.test("get_date_from_mtime: существующий файл",
                  lambda: dt_mtime is not None and dt_mtime.year >= 2020, True)

        # get_date_from_mtime для несуществующего файла
        self.test("get_date_from_mtime: несуществующий → None",
                  lambda: get_date_from_mtime(Path("Z:/imaginary_file_12345.jpg")) is None, True)

        # get_file_date для случайного файла (будет mtime)
        fi = FileInfo(path=Path(__file__), file_type=FileType.PHOTO, extension=".py")
        dt_result, dates = get_file_date(fi, use_ffprobe=False)
        self.test("get_file_date: фото без EXIF → mtime",
                  lambda: dt_result is not None, True)

        print()

    def _test_scanner(self):
        """Тесты scanner.py."""
        print("📁 4. СКАНИРОВАНИЕ (scanner.py)")
        print("-" * 40)

        # Создаём временные тестовые данные
        gen = TestDataGenerator()
        gen.create()
        source = gen.source_dir
        target = gen.target_dir

        # 1. Сканирование папки
        files = list(scan_folder(source, recursive=True))
        media_files = [f for f in files if f.file_type != FileType.UNKNOWN]
        # Из 27 записей: .db, .txt, .md, .py игнорируются и .DS_Store тоже
        # media: jpg(7) + jpeg(2) + png(3) + webp(1) + gif(1) + mp4(1) + mov(1) + avi(1) = 17
        self.test("scan_folder: найдены медиа-файлы",
                  lambda: len(media_files) > 0, True)

        # 2. Без рекурсии
        non_rec_files = list(scan_folder(source, recursive=False))
        self.test("scan_folder: без рекурсии меньше файлов",
                  lambda: len(non_rec_files) <= len(files), True)

        # 3. Пустая папка
        empty_dir = gen.base_dir / "empty"
        empty_dir.mkdir(exist_ok=True)
        empty_files = list(scan_folder(empty_dir))
        self.test("scan_folder: пустая папка → []",
                  lambda: len(empty_files) == 0, True)

        # 4. Несуществующая папка
        try:
            list(scan_folder(Path("Z:/nonexistent_folder_12345")))
            self.failed += 1
            self.errors.append(("scan_folder: несуществующая папка → FileNotFoundError", "Исключение не было выброшено"))
            print("  ❌ scan_folder: несуществующая папка → FileNotFoundError: исключение не было выброшено")
        except FileNotFoundError:
            self.passed += 1
            print("  ✅ scan_folder: несуществующая папка → FileNotFoundError")

        # 5. count_media_files
        count = count_media_files(source)
        self.test("count_media_files: корректный подсчёт",
                  lambda: count == len(media_files), True)

        # 6. Игнорирование системных файлов
        has_db = any(f.path.suffix == '.db' for f in files)
        self.test("scan_folder: .db файлы игнорируются",
                  lambda: not has_db, True)

        gen.cleanup()
        print()

    def _test_sorter(self):
        """Тесты базовой логики sorter.py."""
        print("📁 5. СОРТИРОВЩИК (sorter.py — логика)")
        print("-" * 40)

        # _build_destination_path
        fi = FileInfo(path=Path("test.jpg"), file_type=FileType.PHOTO, extension=".jpg")
        dest = _build_destination_path(fi, Path("/target"), datetime(2013, 3, 10))
        self.test("_build_destination_path: фото 2013-03",
                  lambda: "2013" in dest.parts and "Март_2013" in dest.parts and "Фото" in dest.parts and "test.jpg" == dest.name, True)

        fi2 = FileInfo(path=Path("video.mp4"), file_type=FileType.VIDEO, extension=".mp4")
        dest2 = _build_destination_path(fi2, Path("/target"), datetime(2022, 1, 15))
        self.test("_build_destination_path: видео 2022-01",
                  lambda: "2022" in dest2.parts and "Январь_2022" in dest2.parts and "Видео" in dest2.parts and "video.mp4" == dest2.name, True)

        # _resolve_conflict
        import tempfile
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)
            file1 = tmp / "test.jpg"
            file1.touch()

            # Без конфликта
            resolved = _resolve_conflict(file1)
            self.test("_resolve_conflict: существующий → (1)",
                      lambda: resolved.name == "test (1).jpg", True)

            # С несколькими конфликтами
            file2 = tmp / "test (1).jpg"
            file2.touch()
            resolved2 = _resolve_conflict(file1)
            self.test("_resolve_conflict: двойной конфликт → (2)",
                      lambda: resolved2.name == "test (2).jpg", True)

            # Уникальное имя
            unique = tmp / "unique.jpg"
            resolved3 = _resolve_conflict(unique)
            self.test("_resolve_conflict: уникальное имя → без изменений",
                      lambda: resolved3.name == "unique.jpg", True)

        print()

    def _test_integration(self):
        """Интеграционные тесты — полный цикл сортировки."""
        print("📁 6. ИНТЕГРАЦИОННЫЕ ТЕСТЫ")
        print("-" * 40)

        # Создаём тестовые данные
        gen = TestDataGenerator()
        gen.create()
        source = gen.source_dir
        target = gen.target_dir

        # 1. Dry-run режим
        report_dry = run_sort(source, target, dry_run=True)
        self.test("Dry-run: файлы не перемещены (0 moved)",
                  lambda: report_dry.moved == 0, True)
        self.test("Dry-run: есть файлы в отчёте",
                  lambda: report_dry.total > 0, True)

        # Считаем файлы до перемещения
        files_before = gen.count_files(source)

        # 2. Реальная сортировка (move) — без дедупликации, т.к. тестовые файлы пустые
        report = run_sort(source, target, dry_run=False, copy_mode=False, enable_dedup=False)

        # 3. Проверка безопасности: файлов в source должно стать 0 (или меньше)
        files_in_source = gen.count_files(source)
        media_in_source = count_media_files(source)

        # 4. Проверка, что файлы переместились в target
        files_in_target = gen.count_files(target)

        self.test("Сортировка: есть перемещённые файлы",
                  lambda: report.moved > 0, True)
        self.test("Сортировка: медиа-файлы перемещены из source",
                  lambda: media_in_source == 0, True)
        self.test("Сортировка: файлы появились в target",
                  lambda: files_in_target > 0, True)

        # 5. Проверка структуры папок
        years = [d.name for d in target.iterdir() if d.is_dir()]
        has_year_dirs = any(y.isdigit() for y in years)
        self.test("Структура: созданы папки годов",
                  lambda: has_year_dirs, True)

        # Проверяем, что есть папки "Фото" и "Видео"
        has_photo_folder = any(
            (target / y).exists()
            for y in years
            for y_dir in [target / y]
            if y_dir.is_dir()
            for m_dir in y_dir.iterdir()
            if m_dir.is_dir() and (m_dir / PHOTO_DIR_NAME).exists()
        )

        # Более простая проверка
        all_subdirs = [d for d in target.rglob("*") if d.is_dir()]
        photo_dirs = [d for d in all_subdirs if d.name == PHOTO_DIR_NAME]
        video_dirs = [d for d in all_subdirs if d.name == VIDEO_DIR_NAME]

        self.test("Структура: есть папки 'Фото'",
                  lambda: len(photo_dirs) > 0, True)
        self.test("Структура: есть папки 'Видео'",
                  lambda: len(video_dirs) > 0, True)

        # 6. Проверка конфликта имён (дубликат vacation_2022 из разных подпапок)
        # С USE_SOURCE_FOLDER_PREFIX=True конфликт разрешается префиксом подпапки
        jan_photo_dir = target / "2022" / "Январь_2022" / "Фото"
        if jan_photo_dir.exists():
            files_in_jan = list(jan_photo_dir.iterdir())
            self.test("Конфликт имён: 2+ файла в Январь_2022/Фото",
                      lambda: len(files_in_jan) >= 3, True)
            names = [f.name for f in files_in_jan]
            has_original = any("vacation_2022.jpg" == n for n in names)
            # Теперь с префиксом: duplicate_test_2_vacation_2022.jpg
            has_conflict = any("duplicate_test_2_vacation_2022.jpg" == n for n in names)
            has_other = any("photo_2022_01.jpg" == n for n in names)
            self.test("Конфликт имён: оригинал vacation_2022.jpg сохранён",
                      lambda: has_original, True)
            self.test("Конфликт имён: дубликат с префиксом подпапки",
                      lambda: has_conflict, True)
            self.test("Конфликт имён: photo_2022_01.jpg также есть",
                      lambda: has_other, True)
        else:
            self.test("Конфликт имён: папка сущeствует", lambda: False, True)
            print("  ⚠️  Папка Январь_2022/Фото не найдена")

        # 7. Copy mode
        gen2 = TestDataGenerator()
        gen2.create()
        source2 = gen2.source_dir
        target2 = gen2.target_dir

        report_copy = run_sort(source2, target2, dry_run=False, copy_mode=True, enable_dedup=False)
        files_in_source2 = gen2.count_files(source2)

        self.test("Copy mode: файлы остались в source",
                  lambda: files_in_source2 > 0, True)
        self.test("Copy mode: файлы появились в target",
                  lambda: report_copy.moved > 0, True)

        gen.cleanup()
        gen2.cleanup()
        print()

    def _test_security(self):
        """Критические тесты безопасности."""
        print("🔴 7. ТЕСТЫ БЕЗОПАСНОСТИ")
        print("-" * 40)

        # Проверяем, что в коде sorter.py нет вызовов os.remove или shutil.rmtree
        sorter_path = Path(__file__).parent.parent / "sorter.py"
        sorter_code = sorter_path.read_text(encoding='utf-8')

        dangerous_calls = [
            ("os.remove", "удаление файла"),
            ("os.unlink", "удаление файла"),
            ("shutil.rmtree", "удаление папки"),
            ("path.unlink", "удаление файла через pathlib"),
            ("path.rmdir", "удаление папки через pathlib"),
        ]

        for call, desc in dangerous_calls:
            if call in sorter_code:
                self.failed += 1
                self.errors.append((f"Безопасность: найден опасный вызов {call}", desc))
                print(f"  ❌ Безопасность: найден опасный вызов '{call}' ({desc})")
            else:
                self.passed += 1
                print(f"  ✅ Безопасность: '{call}' не найден ({desc})")

        # Проверяем, что используются только shutil.move и shutil.copy2
        has_move = "shutil.move" in sorter_code
        has_copy = "shutil.copy2" in sorter_code
        self.test("Безопасность: используется shutil.move",
                  lambda: has_move, True)
        self.test("Безопасность: используется shutil.copy2",
                  lambda: has_copy, True)

        print()

    def _print_report(self):
        """Выводит итоговый отчёт."""
        from datetime import datetime as dt2
        total = self.passed + self.failed
        duration = (dt2.now() - self.start_time).total_seconds()

        print()
        print("=" * 70)
        print("  📊 ИТОГОВЫЙ ОТЧЁТ ТЕСТИРОВАНИЯ")
        print("=" * 70)
        print(f"  ✅ Пройдено:  {self.passed}")
        print(f"  ❌ Провалено: {self.failed}")
        print(f"  📊 Всего:     {total}")
        print(f"  ⏱ Время:     {duration:.1f} сек")
        print(f"  📈 Успешность: {self.passed / total * 100:.1f}%" if total > 0 else "  📈 Успешность: N/A")
        print()

        if self.errors:
            print("❌ ОШИБКИ:")
            for name, err in self.errors:
                print(f"   - {name}: {err}")
            print()

        if self.failed == 0:
            print("🎉 ВСЕ ТЕСТЫ ПРОЙДЕНЫ!")
        else:
            print(f"⚠️  {self.failed} тестов провалено. Требуется доработка.")

        print("=" * 70)


if __name__ == "__main__":
    runner = TestRunner()
    runner.run_all()

    # Возвращаем код возврата для CI/CD
    sys.exit(1 if runner.failed > 0 else 0)