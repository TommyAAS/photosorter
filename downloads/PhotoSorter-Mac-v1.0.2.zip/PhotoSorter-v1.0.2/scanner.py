"""
Сканирование папки и фильтрация медиа-файлов.
"""

from pathlib import Path
from typing import Iterator, Set

from photo_sorter.config import ALL_MEDIA_EXTENSIONS, IGNORED_FILES, PHOTO_EXTENSIONS, VIDEO_EXTENSIONS
from photo_sorter.models import FileInfo, FileType


def scan_folder(folder: Path, recursive: bool = True) -> Iterator[FileInfo]:
    """
    Сканирует папку и возвращает все найденные медиа-файлы.
    
    Args:
        folder: Путь к исходной папке
        recursive: Рекурсивный обход подпапок
    
    Yields:
        FileInfo для каждого найденного медиа-файла
    """
    if not folder.exists():
        raise FileNotFoundError(f"Папка не найдена: {folder}")
    if not folder.is_dir():
        raise NotADirectoryError(f"Указанный путь не является папкой: {folder}")

    iterator = folder.rglob("*") if recursive else folder.glob("*")

    for file_path in iterator:
        if not file_path.is_file():
            continue

        # Игнорируем системные файлы
        if file_path.name.lower() in IGNORED_FILES:
            continue

        ext = file_path.suffix.lower()
        if ext not in ALL_MEDIA_EXTENSIONS:
            continue

        if ext in PHOTO_EXTENSIONS:
            file_type = FileType.PHOTO
        elif ext in VIDEO_EXTENSIONS:
            file_type = FileType.VIDEO
        else:
            file_type = FileType.UNKNOWN

        yield FileInfo(path=file_path, file_type=file_type, extension=ext)


def count_media_files(folder: Path, recursive: bool = True) -> int:
    """
    Быстрый подсчёт количества медиа-файлов в папке (без загрузки в память).
    
    Args:
        folder: Путь к папке
        recursive: Рекурсивно или нет
    
    Returns:
        Количество медиа-файлов
    """
    count = 0
    for _ in scan_folder(folder, recursive):
        count += 1
    return count