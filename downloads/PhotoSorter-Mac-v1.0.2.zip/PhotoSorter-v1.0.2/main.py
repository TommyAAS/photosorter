#!/usr/bin/env python3
"""
PhotoSorter — приложение для сортировки фотографий и видео по дате.
Точка входа. Запускает GUI или CLI.
"""

import sys
import logging
from pathlib import Path

# Настройка пути для PyInstaller (чтобы находил ресурсы)
if getattr(sys, 'frozen', False):
    # Запуск из EXE
    BASE_DIR = Path(sys.executable).parent
else:
    BASE_DIR = Path(__file__).parent.parent

logger = logging.getLogger("photo_sorter")


def main():
    """Точка входа в приложение."""
    # По умолчанию запускаем GUI
    try:
        from photo_sorter.app import run_app
        run_app()
    except ImportError as e:
        print(f"❌ Ошибка: {e}")
        print()
        print("Убедитесь, что установлены все зависимости:")
        print("  pip install customtkinter pillow")
        print()
        print("Или соберите EXE:")
        print("  pip install pyinstaller")
        print("  pyinstaller --onefile --windowed --name=PhotoSorter main.py")
        sys.exit(1)


if __name__ == "__main__":
    main()