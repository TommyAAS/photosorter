"""
Извлечение даты создания из медиа-файлов.
Стратегия: самая ранняя валидная EXIF-дата → mtime → сегодня.
"""

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from photo_sorter.config import MIN_VALID_YEAR
from photo_sorter.models import FileInfo, FileType

logger = logging.getLogger(__name__)

# Список EXIF-тегов для чтения в порядке приоритета
EXIF_DATE_TAGS = [
    (0x9003, "DateTimeOriginal"),       # EXIF — оригинальная дата съёмки
    (0x9004, "DateTimeDigitized"),       # EXIF — дата оцифровки
    (0x0132, "DateTime"),                # IFD0 — дата изменения по версии редактора
    (0xa002, "PixelXDimension"),         # не дата, пропускаем
]

# Дополнительные теги для проверки
EXIF_ADDITIONAL_TAGS = {
    0xa004,  # RelatedSoundFile (иногда содержит дату)
    0x9000,  # ExifVersion
    0x9101,  # ComponentsConfiguration
}


def _parse_exif_date(date_str: str) -> Optional[datetime]:
    """
    Парсит EXIF-строку даты в datetime.
    
    EXIF-форматы:
    - "YYYY:MM:DD HH:MM:SS"
    - "YYYY:MM:DD HH:MM:SS\0"
    - "YYYY-MM-DD HH:MM:SS"
    
    Args:
        date_str: Строка даты из EXIF
    
    Returns:
        datetime объект или None, если не удалось распарсить
    """
    if not date_str:
        return None
    
    # Очищаем строку
    date_str = date_str.strip().replace('\x00', '')
    if not date_str:
        return None
    
    # Пробуем разные форматы
    formats = [
        "%Y:%m:%d %H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y:%m:%d",
        "%Y-%m-%d",
    ]
    
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except (ValueError, TypeError):
            continue
    
    return None


def _is_valid_date(dt: Optional[datetime]) -> bool:
    """
    Проверяет, что дата валидна и находится в разумных пределах.
    
    Args:
        dt: Дата для проверки
    
    Returns:
        True, если дата валидна
    """
    if dt is None:
        return False
    
    now = datetime.now()
    # Дата не должна быть раньше MIN_VALID_YEAR и не позже сегодня + 1 день
    if dt.year < MIN_VALID_YEAR:
        return False
    if dt > now:
        # Допускаем +1 день из-за часовых поясов
        diff = (dt - now).total_seconds()
        if diff > 86400:  # больше суток вперёд
            return False
    
    return True


def get_date_from_exif(file_path: Path) -> tuple[Optional[datetime], list[str]]:
    """
    Извлекает все EXIF-даты из файла и возвращает самую раннюю валидную.
    
    Args:
        file_path: Путь к файлу изображения
    
    Returns:
        Кортеж (datetime, список найденных строк с датами)
    """
    found_dates: list[str] = []
    parsed_dates: list[datetime] = []
    
    try:
        from PIL import Image
        from PIL.ExifTags import TAGS
        
        with Image.open(file_path) as img:
            exif_data = img._getexif()
            if exif_data is None:
                return None, found_dates
            
            # Собираем все теги с датами
            for tag_id, value in exif_data.items():
                tag_name = TAGS.get(tag_id, f"Unknown({tag_id})")
                
                # Проверяем, похоже ли значение на дату
                if isinstance(value, str) and (':' in value or '-' in value):
                    found_dates.append(f"{tag_name}: {value}")
                    parsed = _parse_exif_date(value)
                    if parsed and _is_valid_date(parsed):
                        parsed_dates.append(parsed)
                
                # Некоторые камеры хранят дату в байтах
                elif isinstance(value, bytes):
                    try:
                        decoded = value.decode('utf-8', errors='ignore').strip()
                        if ':' in decoded or '-' in decoded:
                            found_dates.append(f"{tag_name}: {decoded}")
                            parsed = _parse_exif_date(decoded)
                            if parsed and _is_valid_date(parsed):
                                parsed_dates.append(parsed)
                    except Exception:
                        pass
    
    except Exception as e:
        logger.debug(f"Ошибка чтения EXIF для {file_path.name}: {e}")
        return None, found_dates
    
    if not parsed_dates:
        return None, found_dates
    
    # Берём самую раннюю валидную дату
    earliest = min(parsed_dates, key=lambda d: d.timestamp())
    return earliest, found_dates


def get_date_from_mtime(file_path: Path) -> Optional[datetime]:
    """
    Извлекает дату модификации файла (mtime).
    
    Args:
        file_path: Путь к файлу
    
    Returns:
        datetime объекта с датой модификации
    """
    try:
        mtime = file_path.stat().st_mtime
        dt = datetime.fromtimestamp(mtime)
        if _is_valid_date(dt):
            return dt
    except Exception as e:
        logger.debug(f"Ошибка получения mtime для {file_path.name}: {e}")
    
    return None


def get_date_from_ffprobe(file_path: Path) -> Optional[datetime]:
    """
    Пытается извлечь дату из метаданных видео через ffprobe.
    
    Args:
        file_path: Путь к видеофайлу
    
    Returns:
        datetime или None
    """
    try:
        import subprocess
        import json
        
        result = subprocess.run(
            ["ffprobe", "-v", "quiet", "-print_format", "json",
             "-show_format", str(file_path)],
            capture_output=True, text=True, timeout=10
        )
        
        if result.returncode != 0:
            return None
        
        data = json.loads(result.stdout)
        format_info = data.get("format", {})
        tags = format_info.get("tags", {})
        
        # Ищем дату в разных тегах
        for key in ("creation_time", "date", "DateTimeOriginal"):
            value = tags.get(key)
            if value:
                parsed = _parse_exif_date(value)
                if parsed and _is_valid_date(parsed):
                    return parsed
    
    except FileNotFoundError:
        pass  # ffprobe не установлен
    except (subprocess.TimeoutExpired, json.JSONDecodeError, Exception) as e:
        logger.debug(f"Ошибка ffprobe для {file_path.name}: {e}")
    
    return None


def get_file_date(file_info: FileInfo, use_ffprobe: bool = True) -> tuple[Optional[datetime], list[str]]:
    """
    Определяет дату создания медиа-файла.
    
    Стратегия:
    1. Для фото: все EXIF-даты → самая ранняя валидная → mtime → сегодня
    2. Для видео: ffprobe (если доступен) → mtime → сегодня
    
    Args:
        file_info: Информация о файле
        use_ffprobe: Использовать ffprobe для видео (если доступен)
    
    Returns:
        Кортеж (datetime, список найденных дат для логирования)
    """
    found_dates: list[str] = []
    result_date: Optional[datetime] = None
    
    if file_info.file_type == FileType.PHOTO:
        # Для фото — EXIF первым приоритетом
        exif_date, exif_dates = get_date_from_exif(file_info.path)
        found_dates.extend(exif_dates)
        
        if exif_date:
            result_date = exif_date
        else:
            # Fallback на mtime
            mtime = get_date_from_mtime(file_info.path)
            if mtime:
                found_dates.append(f"mtime: {mtime.isoformat()}")
                result_date = mtime
    
    elif file_info.file_type == FileType.VIDEO:
        # Для видео — ffprobe (если доступен)
        if use_ffprobe:
            ffprobe_date = get_date_from_ffprobe(file_info.path)
            if ffprobe_date:
                found_dates.append(f"ffprobe: {ffprobe_date.isoformat()}")
                result_date = ffprobe_date
        
        # Fallback на mtime
        if result_date is None:
            mtime = get_date_from_mtime(file_info.path)
            if mtime:
                found_dates.append(f"mtime: {mtime.isoformat()}")
                result_date = mtime
    
    # Финальный fallback — сегодня
    if result_date is None:
        result_date = datetime.now()
        found_dates.append(f"fallback (сегодня): {result_date.isoformat()}")
        logger.warning(
            f"Не удалось определить дату для {file_info.name}. "
            f"Используется текущая дата."
        )
    
    logger.debug(
        f"Дата для {file_info.name}: выбрана {result_date.isoformat()}, "
        f"найдено {len(found_dates)} значений"
    )
    
    return result_date, found_dates