@echo off
chcp 65001 >nul
title PhotoSorter — Сборка EXE

echo =============================================
echo  📸 PhotoSorter — Сборка приложения v1.0.1
echo =============================================
echo.

:: Переходим в родительскую папку (Scandroid)
cd /d "%~dp0.."

:: Проверка Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Python не найден. Установите Python 3.8+
    pause
    exit /b 1
)
echo ✅ Python найден

:: Генерация иконки
echo.
echo 🎨 Генерация иконки...
python photo_sorter\generate_icon.py
if %errorlevel% neq 0 (
    echo ⚠️ Не удалось создать иконку, продолжаем без неё
)

:: Проверка/установка зависимостей
echo.
echo 📦 Установка зависимостей...
pip install -r photo_sorter\requirements.txt
if %errorlevel% neq 0 (
    echo ❌ Ошибка установки зависимостей
    pause
    exit /b 1
)
echo ✅ Зависимости установлены

:: Установка PyInstaller
echo.
echo 📦 Установка PyInstaller...
pip install pyinstaller
if %errorlevel% neq 0 (
    echo ❌ Ошибка установки PyInstaller
    pause
    exit /b 1
)
echo ✅ PyInstaller установлен

:: Проверка наличия иконки
set ICON_ARG=
if exist photo_sorter\icon.ico (
    set ICON_ARG=--icon=photo_sorter\icon.ico
    echo ✅ Иконка найдена
) else (
    echo ⚠️ Иконка не найдена, сборка без иконки
)

:: Сборка EXE
echo.
echo 🔨 Сборка EXE...
pyinstaller ^
    --onefile ^
    --windowed ^
    --name PhotoSorter ^
    --noconfirm ^
    --clean ^
    %ICON_ARG% ^
    --add-data "photo_sorter;photo_sorter" ^
    photo_sorter\main.py

if %errorlevel% neq 0 (
    echo ❌ Ошибка сборки
    pause
    exit /b 1
)

echo.
echo =============================================
echo  ✅ Сборка завершена!
echo =============================================
echo.
echo 📂 EXE находится: %CD%\dist\PhotoSorter.exe
echo.
echo 🔧 Размер:
for %%I in (dist\PhotoSorter.exe) do echo    %%~zI байт
echo.
echo 🚀 Для запуска: dist\PhotoSorter.exe
echo.
pause